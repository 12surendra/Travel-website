<b>#Hi,I am Tharun and welcome to my new project using Html,css and javascript,</b><br>
# Travel-Website-Outlook                              
1.open Travel Website folder                          <br>
2.use index.html file to start                        <br>
3.If u download the code                              <br>
4.Better correct the file paths.                      <br>
<b>#Hope u like the project.<br>
#Feel free to download the source code and follow for new projects.<br>
#dont foget to give a star if u like the project.   <br>
<br>

#Demo VIdeo
link:https://travel-consultancy-website.herokuapp.com/
</b>
